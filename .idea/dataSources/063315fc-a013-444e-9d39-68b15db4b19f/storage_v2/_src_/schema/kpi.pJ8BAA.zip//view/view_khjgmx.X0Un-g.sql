create view view_khjgmx as
select `kh`.`id`   AS `id`,
       `kh`.`JZGH` AS `JZGH`,
       `kh`.`DWH`  AS `DWH`,
       `kh`.`GZH`  AS `GZH`,
       `kh`.`KHNF` AS `KHNF`,
       `kh`.`KHJD` AS `KHJD`,
       `kh`.`KHMX` AS `KHMX`,
       `kh`.`note` AS `note`
from `kpi`.`kh_khjgmx` `kh`
where (1 = 1);

