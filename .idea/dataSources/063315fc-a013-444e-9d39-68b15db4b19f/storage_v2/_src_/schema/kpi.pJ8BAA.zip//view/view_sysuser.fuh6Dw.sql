create view view_sysuser as
select `su`.`id`          AS `id`,
       `su`.`payroll`     AS `payroll`,
       `su`.`password`    AS `password`,
       `su`.`time_pwd`    AS `time_pwd`,
       `su`.`role_id`     AS `role_id`,
       `su`.`usertype_id` AS `usertype_id`,
       `ro`.`role_name`   AS `role_name`,
       `jg`.`JZGH`        AS `JZGH`,
       `jg`.`XM`          AS `XM`,
       `jg`.`DWH`         AS `DWH`,
       `zz`.`DWMC`        AS `DWMC`
from (((`kpi`.`jx_sysuser` `su` left join `kpi`.`jx_role` `ro` on ((`ro`.`id` = `su`.`role_id`))) left join `kpi`.`view_jzgjcsjxx` `jg` on ((`jg`.`JZGH` = `su`.`payroll`)))
         left join `kpi`.`view_zzjgjbsjxx` `zz` on ((`zz`.`DWH` = `jg`.`DWH`)));

