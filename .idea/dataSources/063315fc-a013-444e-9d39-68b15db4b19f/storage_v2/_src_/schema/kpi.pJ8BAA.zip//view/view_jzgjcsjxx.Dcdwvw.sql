create view view_jzgjcsjxx as
select `dr`.`id`     AS `id`,
       `dr`.`JZGH`   AS `JZGH`,
       `dr`.`DWH`    AS `DWH`,
       `dr`.`XM`     AS `XM`,
       `dr`.`YWXM`   AS `YWXM`,
       `dr`.`XMPY`   AS `XMPY`,
       `dr`.`CYM`    AS `CYM`,
       `dr`.`XBM`    AS `XBM`,
       `dr`.`CSRQ`   AS `CSRQ`,
       `dr`.`CSDM`   AS `CSDM`,
       `dr`.`BZLBM`  AS `BZLBM`,
       `dr`.`JZGLBM` AS `JZGLBM`,
       `dr`.`DQZTM`  AS `DQZTM`,
       `dr`.`stamp`  AS `stamp`,
       `dr`.`note`   AS `note`
from (`kpi`.`dr_jzgjcsjxx` `dr`
         left join `kpi`.`dc_jzgjcsjxx` `dc` on ((`dc`.`JZGH` = `dr`.`JZGH`)))
where (1 = 1);

