create view view_jxkhgz as
select `kh`.`id`     AS `id`,
       `kh`.`GZH`    AS `GZH`,
       `kh`.`DWH`    AS `DWH`,
       `kh`.`KHLX`   AS `KHLX`,
       `kh`.`KHZL`   AS `KHZL`,
       `kh`.`XXKLZL` AS `XXKLZL`,
       `kh`.`KHMC`   AS `KHMC`,
       `kh`.`KHSJDX` AS `KHSJDX`,
       `kh`.`GZTJ`   AS `GZTJ`,
       `kh`.`JXFSJS` AS `JXFSJS`,
       `kh`.`KHMXMB` AS `KHMXMB`,
       `kh`.`KHJGDX` AS `KHJGDX`,
       `kh`.`note`   AS `note`
from `kpi`.`kh_jxkhgz` `kh`
where (1 = 1);

