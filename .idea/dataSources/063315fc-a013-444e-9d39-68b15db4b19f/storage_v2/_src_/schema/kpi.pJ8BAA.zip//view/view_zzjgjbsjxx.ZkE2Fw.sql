create view view_zzjgjbsjxx as
select `dr`.`id`     AS `id`,
       `dr`.`DWH`    AS `DWH`,
       `dr`.`DWMC`   AS `DWMC`,
       `dr`.`DWYWMC` AS `DWYWMC`,
       `dr`.`DWJC`   AS `DWJC`,
       `dr`.`DWYWJC` AS `DWYWJC`,
       `dr`.`DWJP`   AS `DWJP`,
       `dr`.`DWDZ`   AS `DWDZ`,
       `dr`.`SZXQ`   AS `SZXQ`,
       `dr`.`LSDWH`  AS `LSDWH`,
       `dr`.`DWLBM`  AS `DWLBM`,
       `dr`.`DWBBM`  AS `DWBBM`,
       `dr`.`DWYXBS` AS `DWYXBS`,
       `dr`.`SXRQ`   AS `SXRQ`,
       `dr`.`SFST`   AS `SFST`,
       `dr`.`JLNY`   AS `JLNY`,
       `dr`.`DWFZRH` AS `DWFZRH`,
       `dr`.`stamp`  AS `stamp`,
       `dr`.`note`   AS `note`
from (`kpi`.`dr_zzjgjbsjxx` `dr`
         left join `kpi`.`dc_zzjgjbsjxx` `dc` on ((`dc`.`DWH` = `dr`.`DWH`)))
where (1 = 1);

