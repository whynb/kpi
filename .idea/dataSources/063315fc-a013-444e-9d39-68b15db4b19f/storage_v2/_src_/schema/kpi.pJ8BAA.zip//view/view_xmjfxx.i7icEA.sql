create view view_xmjfxx as
select `dr`.`id`       AS `id`,
       `dr`.`JHJFZE`   AS `JHJFZE`,
       `dr`.`XMJFLYM`  AS `XMJFLYM`,
       `dr`.`BRRQ`     AS `BRRQ`,
       `dr`.`BKS`      AS `BKS`,
       `dr`.`ZCRQ`     AS `ZCRQ`,
       `dr`.`BFXZDWJF` AS `BFXZDWJF`,
       `dr`.`XMPZBH`   AS `XMPZBH`,
       `dr`.`JBRXM`    AS `JBRXM`,
       `dr`.`XMBH`     AS `XMBH`,
       `dr`.`ZZKS`     AS `ZZKS`,
       `jz`.`JZGH`     AS `JZGH`,
       `jz`.`DWH`      AS `DWH`,
       `dr`.`BRRQ`     AS `stamp`,
       `dr`.`note`     AS `note`
from ((`kpi`.`dr_xmjfxx` `dr` left join `kpi`.`dc_xmjfxx` `dc` on ((`dc`.`XMBH` = `dr`.`XMBH`)))
         left join `kpi`.`dr_jzgjcsjxx` `jz` on ((`jz`.`JZGH` = `dr`.`JZGH`)))
where (1 = 1);

